package com.ebikedoctor.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101820)
private val Panel = Color(0xFF1B2933)
private val Lime = Color(0xFFB6F36B)
private val Ink = Color(0xFFEAF1F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DoctorApp() }
    }
}

private data class Fault(val code: String, val system: String, val huTitle: String, val enTitle: String, val huBody: String, val enBody: String, val tags: String)
private data class Guide(val huTitle: String, val enTitle: String, val huBody: String, val enBody: String, val category: String)

private val faults = listOf(
    Fault("E06", "S866 / controller-dependent", "Alacsony feszültség vagy tápellátási hiba", "Low voltage or power supply fault", "Ellenőrizd az akkumulátor feszültségét terhelés nélkül és terhelés alatt, a csatlakozókat és a vezérlő feszültséghatárát. Az E06 jelentése vezérlőfüggő.", "Check battery voltage at rest and under load, connectors, and the controller's voltage threshold. E06 meaning depends on the controller.", "battery voltage controller S866"),
    Fault("E07", "SW900 / controller-dependent", "Motor- vagy vezérlőhiba lehet", "Possible motor or controller fault", "Ellenőrizd a motorfázisok csatlakozását, a kábel sérülését és – ha a motor ilyen – a Hall-szenzorok jelét. Ne cserélj fázisokat találomra, terhelés nélkül vizsgálj.", "Inspect motor phase connections, cable damage, and Hall sensor signals if fitted. Do not swap phases randomly; test without load.", "motor phase hall controller SW900"),
    Fault("E10", "Fischer / system-dependent", "Kommunikációs vagy hőmérsékleti hiba lehet", "Possible communication or temperature fault", "A pontos jelentés a motorrendszertől függ. Írd fel a motor, kijelző és vezérlő típusát; ellenőrizd a csatlakozókat és a kábelköteget. Ne tekintsd univerzális kódnak.", "Exact meaning depends on the drive system. Record motor, display and controller model; inspect connectors and harness. This is not a universal code.", "Fischer communication temperature"),
    Fault("E14", "Invanti / model-dependent", "Gázkar vagy vezérlőjel hiba lehet", "Possible throttle or controller signal fault", "Ellenőrizd, hogy az adott típus használ-e gázkart, majd a csatlakozót, a tápot és a jelvezetéket a gyártói kapcsolási rajz szerint.", "Check whether the model uses a throttle, then inspect its connector, supply and signal wire using the manufacturer's wiring diagram.", "Invanti throttle signal"),
    Fault("4", "YL81F display / model-dependent", "Gázkar-jel hibája lehet", "Possible throttle signal fault", "Egyes YL81F konfigurációknál a 4-es kód a gázkar jeléhez kapcsolódik. Húzd le a tápot, vizsgáld meg a csatlakozót, és csak a konkrét vezérlő dokumentációja alapján mérj.", "On some YL81F configurations, code 4 relates to the throttle signal. Disconnect power, inspect the connector, and test only against the exact controller documentation.", "YL81F throttle"),
    Fault("No assist", "All systems / symptom", "Nincs rásegítés", "No pedal assistance", "Ellenőrizd az akkumulátort, a kijelző hibajelzését, a fékkapcsolókat, a PAS érzékelőt, a motorkábelt és a vezérlő csatlakozóit. Középmotornál a gyártóspecifikus diagnosztika is szükséges lehet.", "Check battery, display warnings, brake cutoffs, PAS sensor, motor cable and controller connectors. Mid-drive systems may require manufacturer-specific diagnostics.", "PAS battery brake sensor"),
    Fault("Weak motor", "All systems / symptom", "Gyenge motorerő", "Weak motor output", "Mérd meg az akkumulátor feszültségesését terhelés alatt, ellenőrizd a fékek szabad futását, a csatlakozókat és a beállított áramkorlátot. Melegedő csatlakozó vagy vezérlő esetén azonnal állj le.", "Measure battery sag under load, check brake drag, connectors and configured current limit. Stop immediately if a connector or controller overheats.", "weak power voltage sag controller"),
    Fault("Battery drains", "Battery / symptom", "Gyors önkisülés vagy fogyasztás", "Rapid self-discharge or parasitic draw", "Mérd meg a pakk feszültségét leválasztva, majd ellenőrizd a BMS és a vezérlő nyugalmi fogyasztását a megfelelő műszerrel. Ne bonts feszültség alatt lévő pakkot.", "Measure pack voltage disconnected, then check BMS and controller standby draw with suitable equipment. Never open a live battery pack.", "BMS self discharge drain"),
    Fault("E08", "Controller / model-dependent", "Gázkar vagy jeladó hiba lehet", "Possible throttle or sensor fault", "A jelentés vezérlőfüggő. Ellenőrizd a pontos típust, a csatlakozót és a vezeték sérülését. Mérést csak a gyártói rajz alapján végezz.", "Meaning depends on controller. Confirm exact model, connector and cable condition. Measure only using the manufacturer's wiring diagram.", "throttle sensor controller"),
    Fault("E09", "Controller / model-dependent", "Vezérlőhiba lehet", "Possible controller fault", "Ne tekintsd univerzális kódnak. Jegyezd fel a kijelző és vezérlő típusát, majd ellenőrizd a csatlakozókat és a gyártói hibakódlistát.", "Not a universal code. Record display and controller models, inspect connectors and check the manufacturer's fault list.", "controller error"),
    Fault("E-bike shuts off under load", "Battery / symptom", "Terhelésre lekapcsol", "Cuts out under load", "Lehetséges ok a feszültségesés, gyenge cellacsoport, BMS túláramvédelem vagy melegedő csatlakozó. Rögzítsd a nyugalmi és terhelés alatti feszültséget megfelelő terhelésvizsgálóval.", "Possible causes include voltage sag, weak cell group, BMS overcurrent protection or a hot connector. Record resting and loaded voltage using a suitable load tester.", "cutout load voltage sag BMS"),
    Fault("Motor jerks", "Motor / symptom", "A motor rángatva indul", "Motor starts with jerking", "Ellenőrizd a csatlakozókat, fáziskábeleket és – ha van – Hall-jeladókat. A vezeték színei nem garantáltan szabványosak. Ne próbálgass fáziskombinációkat terhelés alatt.", "Inspect connectors, phase wires and Hall sensors if fitted. Wire colours are not guaranteed standards. Never experiment with phase combinations under load.", "jerk hall phase motor"),
    Fault("No display", "Power / symptom", "A kijelző nem kapcsol be", "Display will not power on", "Ellenőrizd az akkumulátor fő kimenetét, biztosítékot, főkapcsolót és a kijelző csatlakozóját. Kommunikációs vezetékekre ne adj akkufeszültséget.", "Check battery output, fuse, main switch and display connector. Never apply pack voltage to communication wires.", "display power fuse"),
    Fault("Charger stays green", "Battery / symptom", "A töltő zöld marad", "Charger stays green", "Ellenőrizd a töltő kimenetét és a pakk feszültségét a gyártói határértékek szerint. Lehetséges hibás töltő, megszakadt töltőcsatlakozás vagy BMS-védelem. Ne hidald át a BMS-t.", "Check charger output and pack voltage against manufacturer limits. Possible causes include a faulty charger, broken charge connection or BMS protection. Do not bypass the BMS.", "charger BMS green"),
    Fault("Brake cutoff", "Control / symptom", "A fékszenzor letiltja a motort", "Brake sensor cuts motor", "Ellenőrizd, hogy a fékkar teljesen visszatér-e, a mágnes/szenzor a helyén van-e, és nincs-e sérült kábel. Ne iktasd ki tartósan a biztonsági fékletiltást.", "Check lever return, sensor/magnet alignment and cable damage. Do not permanently disable the safety brake cutoff.", "brake cutoff sensor"),
    Fault("PAS not detected", "Pedal sensor / symptom", "A pedálszenzor nem érzékel", "PAS not detected", "Ellenőrizd a mágnesgyűrű irányát, hézagát, a csatlakozót és a beállított rásegítési szintet. Táp- és jelvezetékeket csak a konkrét kapcsolási rajz alapján mérj.", "Check magnet ring direction, gap, connector and assist level. Measure supply and signal wires only using the exact wiring diagram.", "PAS cadence sensor"),
    Fault("BMS protection", "Battery / symptom", "A BMS védelmi állapotban lehet", "BMS may be in protection", "Lehetséges kiváltó ok túl alacsony vagy magas cellafeszültség, túláram, túlmelegedés vagy érzékelőhiba. Ne ébreszd vagy hidald át találomra; használd a megfelelő gyártói eljárást.", "Possible triggers include cell undervoltage/overvoltage, overcurrent, overheating or sensor fault. Do not wake or bypass it randomly; follow the correct manufacturer's procedure.", "BMS protection cell voltage temperature")
)

private val guides = listOf(
    Guide("Mechanikus fék ellenőrzése", "Mechanical brake inspection", "1. Ellenőrizd a betét vastagságát és a tárcsa állapotát.\n2. Nézd meg a bowden vagy hidraulikus vezeték sérülését.\n3. Forgasd meg a kereket, ellenőrizd a súrlódást.\n4. Javítás után álló helyzetben, majd kis sebességnél tesztelj.", "1. Inspect pad thickness and rotor condition.\n2. Check cable or hydraulic hose damage.\n3. Spin the wheel and check for drag.\n4. After repair, test stationary, then at low speed.", "Mechanika / Mechanical"),
    Guide("PAS érzékelő hibakeresése", "PAS sensor troubleshooting", "1. Ellenőrizd a mágnesgyűrű irányát és távolságát.\n2. Nézd meg a csatlakozót és a vezetéket.\n3. A táp- és jelvezetékeket csak a konkrét rendszer rajza szerint mérd.\n4. Ellenőrizd a kijelző rásegítési szintjét és a fékszenzorokat.", "1. Check magnet ring direction and gap.\n2. Inspect connector and cable.\n3. Measure supply and signal wires only using the exact system diagram.\n4. Check assist level and brake cut-off sensors.", "Elektromos / Electrical"),
    Guide("Akkumulátor terheléses vizsgálata", "Battery load test", "1. Azonosítsd a névleges feszültséget és a cellakémiát.\n2. Mérd meg a nyugalmi feszültséget.\n3. Használj biztosított, megfelelő terhelésvizsgálót és tartsd be a gyártói áramhatárt.\n4. Jegyezd fel a terhelés alatti feszültséget és a visszaállást.\n5. Duzzadt, sérült, szokatlanul meleg vagy szagú akkumulátort ne terhelj és ne tölts.", "1. Identify nominal voltage and chemistry.\n2. Measure resting voltage.\n3. Use a fused, suitable load tester within the manufacturer's current limits.\n4. Record loaded voltage and recovery.\n5. Do not load or charge a swollen, damaged, unusually hot or odorous battery.", "Akkumulátor / Battery"),
    Guide("BMS és cellacsoportok alapellenőrzése", "BMS and cell-group checks", "A pakk felnyitása tűz- és áramütésveszélyes, szakembernek való feladat. Kívülről ellenőrizd a házat, csatlakozót és töltőt. Belső méréshez megfelelő szigetelt eszköz, biztosított munkakörnyezet és cellakémia-ismeret szükséges. Ne hidald át a BMS-t, ne zárd rövidre a cellákat.", "Opening a pack creates fire and shock hazards and should be done by trained technicians. Externally inspect case, connector and charger. Internal tests require insulated tools, a protected workspace and chemistry knowledge. Never bypass the BMS or short cells.", "Akkumulátor / Battery")    ,Guide("Hajtáslánc és lánc ellenőrzése", "Drivetrain and chain inspection", "1. Tisztítsd meg és vizsgáld meg a láncot, lánckereket és váltógörgőket.\n2. Mérj láncnyúlást megfelelő mérővel.\n3. Ellenőrizd a váltóhatárolókat és a bowden feszességét.\n4. Kenés után töröld le a felesleget, majd állványon teszteld.", "1. Clean and inspect chain, sprockets and derailleur pulleys.\n2. Measure chain wear with a suitable gauge.\n3. Check derailleur limits and cable tension.\n4. Lubricate, wipe excess and test on a stand.", "Mechanika / Mechanical"),
    Guide("Kerékcsapágy és kotyogás", "Wheel bearing play", "1. Emeld meg a kereket, forgasd meg, figyeld a zajt.\n2. Oldalirányú mozgatással ellenőrizd a kotyogást.\n3. Különítsd el a tengely, agycsapágy és váz/forka problémáját.\n4. A tengelyt a gyártó nyomatékával húzd meg.", "1. Lift and spin the wheel, listening for noise.\n2. Check side play.\n3. Distinguish axle, hub bearing and frame/fork issues.\n4. Tighten to the manufacturer's torque.", "Mechanika / Mechanical"),
    Guide("Hall-szenzor és fáziskábel alapellenőrzése", "Hall sensor and phase-wire checks", "A motor/vezérlő típusát előbb azonosítsd. Áramtalanítva ellenőrizd a csatlakozókat és a kábeleket. Hall-szenzor méréséhez a megfelelő táp, föld és jel kiosztása kell; a színek nem univerzálisak. Ne köss össze találomra vezetékeket.", "Identify motor/controller first. With power disconnected, inspect connectors and cables. Hall testing requires the correct supply, ground and signal pinout; colours are not universal. Never connect wires at random.", "Elektromos / Electrical")

)

@Composable
private fun DoctorApp() {
    var english by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val titles = if (english) listOf("Home", "Fault codes", "Repair guides", "Battery", "Calculators") else listOf("Kezdőlap", "Hibakódok", "Javítás", "Akkumulátor", "Kalkulátorok")
    MaterialTheme(colorScheme = darkColorScheme(primary = Lime, onPrimary = Navy, background = Navy, surface = Panel, onSurface = Ink, onBackground = Ink)) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBarCustom(english, { english = it }, if (english) "E-Bike Doctor" else "E-Bike Doctor")
        }, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Ink) {
                val icons = listOf(Icons.Default.Home, Icons.Default.Search, Icons.Default.Build, Icons.Default.BatteryChargingFull, Icons.Default.Calculate)
                titles.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], contentDescription = label) }, label = { Text(label, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Lime, indicatorColor = Color(0xFF33442D), selectedTextColor = Lime, unselectedTextColor = Ink)) }
            }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> HomeScreen(english, onSelect = { tab = it })
                    1 -> FaultScreen(english)
                    2 -> GuideScreen(english)
                    3 -> BatteryScreen(english)
                    else -> CalculatorScreen(english)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarCustom(english: Boolean, setEnglish: (Boolean) -> Unit, title: String) {
    TopAppBar(title = { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ElectricBike, null, tint = Lime, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.Bold) } }, actions = {
        TextButton(onClick = { setEnglish(!english) }) { Text(if (english) "EN | HU" else "HU | EN", color = Lime) }
    }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Ink))
}

@Composable
private fun HomeScreen(en: Boolean, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(if (en) "Your workshop companion" else "A műhelytársad", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(if (en) "Offline diagnostics and repair references" else "Offline diagnosztika és javítási útmutatók", color = Lime)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Color(0xFF35444D))) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (en) "QUICK DIAGNOSIS" else "GYORS HIBAKERESÉS", color = Lime, fontWeight = FontWeight.Bold)
                Text(if (en) "Search by code, component or symptom." else "Keress hibakód, alkatrész vagy tünet alapján.")
                Button(onClick = { onSelect(1) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text(if (en) "Search fault codes" else "Hibakód keresése") }
            }
        }
        val cards = if (en) listOf("Repair guides" to "Mechanical and electrical step-by-step checks", "Battery & BMS" to "Cell groups, voltage sag and safety", "Calculators" to "Wh, series/parallel packs and voltage") else listOf("Javítási útmutatók" to "Mechanikus és elektromos ellenőrzések", "Akkumulátor és BMS" to "Cellacsoportok, feszültségesés és biztonság", "Kalkulátorok" to "Wh, soros/párhuzamos pakkok, feszültség")
        cards.forEachIndexed { idx, item ->
            OutlinedCard(onClick = { onSelect(idx + 2) }, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.outlinedCardColors(containerColor = Panel), border = BorderStroke(1.dp, Color(0xFF35444D))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(listOf(Icons.Default.Build, Icons.Default.BatteryChargingFull, Icons.Default.Calculate)[idx], null, tint = Lime, modifier = Modifier.size(32.dp)); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(item.first, fontWeight = FontWeight.Bold); Text(item.second, color = Color.LightGray, fontSize = 13.sp) }; Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        Text(if (en) "Safety: fault-code meanings vary by exact model. Verify against manufacturer documentation." else "Biztonság: a hibakód jelentése pontos modelltől függ. Ellenőrizd a gyártói dokumentációt.", color = Color(0xFFFFD180), fontSize = 12.sp)
    }
}

@Composable
private fun FaultScreen(en: Boolean) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Fault?>(null) }
    val filtered = faults.filter { f -> listOf(f.code, f.system, f.huTitle, f.enTitle, f.huBody, f.enBody, f.tags).any { it.contains(query, true) } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(if (en) "Fault code database" else "Hibakód-adatbázis", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (en) "Code, brand, symptom…" else "Kód, márka, tünet…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        if (selected != null) {
            TextButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, null); Text(if (en) "Back to results" else "Vissza a találatokhoz") }
            selected!!.let { f -> Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("${f.code} · ${f.system}", color = Lime, fontWeight = FontWeight.Bold)
                Text(if (en) f.enTitle else f.huTitle, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (en) f.enBody else f.huBody)
                Text(if (en) "Always confirm the code for the exact model." else "Mindig ellenőrizd a kódot a pontos modell dokumentációjában.", color = Color(0xFFFFD180), fontSize = 12.sp)
            } } }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered) { f -> Card(onClick = { selected = f }, colors = CardDefaults.cardColors(containerColor = Panel)) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Color(0xFF33442D), shape = MaterialTheme.shapes.medium) { Text(f.code, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Lime, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(if (en) f.enTitle else f.huTitle, fontWeight = FontWeight.SemiBold); Text(f.system, color = Color.LightGray, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Lime)
                } } }
            }
        }
    }
}

@Composable
private fun GuideScreen(en: Boolean) {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(if (en) "Repair guides" else "Javítási útmutatók", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (en) "Search guides" else "Útmutató keresése") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(guides.filter { (if (en) it.enTitle + it.enBody else it.huTitle + it.huBody + it.category).contains(query, true) }) { g ->
                var expanded by remember { mutableStateOf(false) }
                Card(colors = CardDefaults.cardColors(containerColor = Panel), onClick = { expanded = !expanded }) { Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(if (en) g.enTitle else g.huTitle, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(g.category, color = Lime, fontSize = 12.sp)
                    if (expanded) { Spacer(Modifier.height(10.dp)); Text(if (en) g.enBody else g.huBody) } else Text(if (en) "Tap to open steps" else "Koppints a lépésekhez", color = Color.LightGray, fontSize = 12.sp)
                } }
            }
        }
    }
}

@Composable
private fun BatteryScreen(en: Boolean) {
    var series by remember { mutableStateOf("10") }
    var parallel by remember { mutableStateOf("4") }
    var cellV by remember { mutableStateOf("3.6") }
    var cellAh by remember { mutableStateOf("3.5") }
    val s = series.toIntOrNull()?.coerceIn(1, 100) ?: 1
    val p = parallel.toIntOrNull()?.coerceIn(1, 100) ?: 1
    val v = cellV.toDoubleOrNull() ?: 0.0
    val ah = cellAh.toDoubleOrNull() ?: 0.0
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (en) "Battery & BMS" else "Akkumulátor és BMS", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (en) "Pack configuration calculator" else "Akkumulátor-konfiguráció kalkulátor", fontWeight = FontWeight.Bold, color = Lime)
            NumberField(if (en) "Series groups (S)" else "Soros csoportok (S)", series) { series = it }
            NumberField(if (en) "Parallel cells (P)" else "Párhuzamos cellák (P)", parallel) { parallel = it }
            NumberField(if (en) "Nominal cell voltage (V)" else "Cella névleges feszültsége (V)", cellV) { cellV = it }
            NumberField(if (en) "Cell capacity (Ah)" else "Cella kapacitása (Ah)", cellAh) { cellAh = it }
            Divider(color = Color(0xFF35444D))
            ResultRow(if (en) "Nominal pack voltage" else "Pakk névleges feszültsége", "%.2f V".format(s * v))
            ResultRow(if (en) "Pack capacity" else "Pakk kapacitása", "%.2f Ah".format(p * ah))
            ResultRow("Energy", "%.1f Wh".format(s * v * p * ah))
            ResultRow(if (en) "Cell count" else "Cellák száma", "${s * p}")
        } }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (en) "Safe diagnostic checklist" else "Biztonságos diagnosztikai ellenőrzőlista", fontWeight = FontWeight.Bold, color = Lime)
            listOf(if (en) "Inspect pack case and connector for heat or damage." else "Ellenőrizd a házat és csatlakozót melegedésre, sérülésre.", if (en) "Measure resting voltage with a suitable meter." else "Mérj nyugalmi feszültséget megfelelő műszerrel.", if (en) "Record voltage sag using a fused, rated load tester." else "Rögzítsd a feszültségesést megfelelő, biztosított terhelésvizsgálóval.", if (en) "Do not bypass the BMS or short cell groups." else "Ne hidald át a BMS-t és ne zárd rövidre a cellacsoportokat.", if (en) "Stop if swollen, damaged, hot, hissing or smelling." else "Állj le, ha duzzadt, sérült, forró, sziszeg vagy szaga van.").forEach { line -> Row(verticalAlignment = Alignment.Top) { Icon(Icons.Default.CheckCircleOutline, null, tint = Lime, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(line, fontSize = 13.sp) } }
        } }
    }
}

@Composable
private fun CalculatorScreen(en: Boolean) {
    var volts by remember { mutableStateOf("36") }
    var amps by remember { mutableStateOf("15") }
    var wattHours by remember { mutableStateOf("500") }
    var watts by remember { mutableStateOf("250") }
    val v = volts.toDoubleOrNull() ?: 0.0
    val a = amps.toDoubleOrNull() ?: 0.0
    val wh = wattHours.toDoubleOrNull() ?: 0.0
    val w = watts.toDoubleOrNull() ?: 0.0
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (en) "Technical calculators" else "Műszaki kalkulátorok", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (en) "Electrical power" else "Elektromos teljesítmény", color = Lime, fontWeight = FontWeight.Bold)
            NumberField(if (en) "Voltage (V)" else "Feszültség (V)", volts) { volts = it }
            NumberField(if (en) "Current (A)" else "Áramerősség (A)", amps) { amps = it }
            ResultRow(if (en) "Power (V × A)" else "Teljesítmény (V × A)", "%.1f W".format(v * a))
        } }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (en) "Estimated runtime" else "Becsült üzemidő", color = Lime, fontWeight = FontWeight.Bold)
            NumberField(if (en) "Battery energy (Wh)" else "Akkumulátor energia (Wh)", wattHours) { wattHours = it }
            NumberField(if (en) "Average load (W)" else "Átlagos terhelés (W)", watts) { watts = it }
            ResultRow(if (en) "Ideal runtime" else "Elméleti üzemidő", if (w > 0) "%.2f h".format(wh / w) else "—")
            Text(if (en) "Real-world range is lower due to losses, terrain, temperature and battery age." else "A valós üzemidő rövidebb a veszteségek, terep, hőmérséklet és akkumulátor-öregedés miatt.", color = Color.LightGray, fontSize = 12.sp)
        } }
    }
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = { next -> if (next.matches(Regex("[0-9]*[.,]?[0-9]*"))) onChange(next.replace(',', '.')) }, modifier = Modifier.fillMaxWidth(), label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
}

@Composable
private fun ResultRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(label, color = Color.LightGray); Text(value, color = Lime, fontWeight = FontWeight.Bold) }
}
