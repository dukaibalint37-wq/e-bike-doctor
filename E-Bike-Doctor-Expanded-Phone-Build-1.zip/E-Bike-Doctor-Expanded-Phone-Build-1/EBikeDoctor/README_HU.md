# E-Bike Doctor – Android forrás és APK-építés telefonról

Ez a csomag egy korai, offline használatra tervezett Android-projektet tartalmaz magyar/angol felülettel, hibakeresési adatbázissal, javítási útmutatókkal, akkumulátor-konfigurációs és elektromos kalkulátorokkal. A kódok rendszerfüggők; a gyártói dokumentációt mindig ellenőrizni kell.

## APK készítése kizárólag telefonról GitHub Actions segítségével

1. A telefon Fájlok alkalmazásában bontsd ki a ZIP-et.
2. A GitHub tárházadban (`e-bike-doctor`) nyisd meg a `main` ágat, és töltsd fel a projekt teljes tartalmát úgy, hogy a `app`, `gradle.properties`, `build.gradle.kts`, `settings.gradle.kts` és `.github/workflows/android-apk.yml` közvetlenül a tárház gyökerében legyenek. Ne töltsd fel csak a ZIP-et.
3. A feltöltést a GitHub webes felületén lehet elvégezni; mobilon válaszd az „Upload files” lehetőséget. Ha nem jelenik meg, Chrome menü → „Asztali webhely”. Több fájl/mappa kiválasztása telefononként eltérhet; szükség esetén a GitHub webes felületén egyesével hozd létre/fel a fájlokat.
4. Nyisd meg a tárházban az **Actions** fület. Ha kéri, engedélyezd a workflow-k futtatását.
5. Válaszd a **Build E-Bike Doctor APK** workflow-t, majd **Run workflow**. Push esetén automatikusan is elindul.
6. Ha a futás zöld pipával befejeződött, nyisd meg a futást, görgess az **Artifacts** részhez, és töltsd le az `E-Bike-Doctor-debug-apk` csomagot. Bontsd ki; benne lesz az `app-debug.apk`.
7. Nyisd meg az APK-t, és ha Android kéri, engedélyezd az adott fájlkezelő/böngésző számára az „Ismeretlen alkalmazások telepítése” engedélyt. Csak a saját, általad épített APK-t telepítsd.

## Megjegyzések
- Az APK-t a GitHub Actions építi felhőben; a telefon csak a feltöltéshez és letöltéshez kell.
- Ez debug APK, nem Google Playre publikált kiadás. Publikáláshoz külön aláírási kulcs és kiadási folyamat kell.
- A hibakód-adatbázis kezdeti, nem teljes és nem minden gyártóra hitelesített. Kódot soha ne tekints univerzálisnak.
- Akkumulátor belső javítása, cellák mérése és BMS megkerülése veszélyes. Ne hidald át a BMS-t és ne rövidzárd a cellákat.
