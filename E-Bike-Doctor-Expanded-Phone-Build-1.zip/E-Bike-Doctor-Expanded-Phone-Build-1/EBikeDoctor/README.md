# E-Bike Doctor

Offline-first Android workshop companion with Hungarian/English UI, fault/symptom search, repair guides, battery configuration and electrical calculators.

See [README_HU.md](README_HU.md) for phone-only GitHub Actions APK build instructions.

This is an early prototype. Fault-code meanings vary by exact system and must be verified against manufacturer documentation. It is not a substitute for safe battery service training.
